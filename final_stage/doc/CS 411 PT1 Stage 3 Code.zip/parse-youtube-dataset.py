from tqdm import tqdm
import os
import csv
import codecs

filename = os.path.abspath("data/US_youtube_trending_data.csv")

def mod_date(d):
    return d.replace('T', ' ').replace('Z', '')

def mod_quote(d):
    d = d.strip().replace('\'', '\'\'')
    if len(d) == 0:
        return '//*NUL*//'
    return d

# def mod_desc(d):
#     return d.replace('\r\n', '\n').replace('\r', '\n').replace('\n', '<br/>')

csv_file = codecs.open(filename, 'rb', 'utf-8')
csv_reader = csv.reader(x.replace('\x00', '') for x in csv_file)
csv_attr = next(csv_reader)

tags_list = []
tags_map = {}
channel_list = []
row_count = 0
for data in tqdm(csv_reader):
    data = list(map(mod_quote, data))
    tags_list.extend([t.strip() for t in data[7].split('|')])
    channel_list.append((data[3], data[4]))
    row_count += 1

tags_list = sorted(list(filter(lambda t: len(t) > 0, set(tags_list))))
tags_map = {tags_list[i]: i for i in range(len(tags_list))}
channel_list = sorted(list(set(channel_list)))

insert_video_tags = """
INSERT INTO VideoTags VALUES
"""
for i in tqdm(range(len(tags_list)), total=len(tags_list), desc='prep insert video tags'):
    insert_video_tags += f"    ({i}, '{tags_list[i]}'),\n"
insert_video_tags = insert_video_tags[:-2] + ";\n"

insert_channels = """
INSERT INTO Channels VALUES
"""
for i in tqdm(range(len(channel_list)), total=len(channel_list), desc='prep insert channels'):
    insert_channels += f"    ('{channel_list[i][0]}', '{channel_list[i][1]}'),\n"
insert_channels = insert_channels[:-2] + ";\n"

csv_file.close()

################################################################################################

csv_file = codecs.open(filename, 'rb', 'utf-8')
csv_reader = csv.reader(x.replace('\x00', '') for x in csv_file)
csv_attr = next(csv_reader)

video_set = set()
insert_videos = """
INSERT INTO Videos VALUES
"""
insert_has_tag = """
INSERT INTO HasTag VALUES
"""
for data in tqdm(csv_reader, total=row_count, desc='prep insert videos'):
    data = list(map(mod_quote, data))
    if data[0] in video_set:
        continue
    video_set.add(data[0])
    insert_videos += f"    ('{data[0]}', '{data[1]}', '{mod_date(data[2])}', "\
                     f"'{data[3]}', {data[5]}, '{mod_date(data[6])}', "\
                     f"{data[8]}, {data[9]}, {data[10]}, {data[11]}, "\
                     f"{1 if data[13].strip() != 'FALSE' else 0}, "\
                     f"{1 if data[14].strip() != 'FALSE' else 0}, '{data[15]}'),\n"
    for t in [t.strip() for t in data[7].split('|')]:
        if len(t) > 0:
            insert_has_tag += f"    ('{data[0]}', {tags_map[t]}),\n"
insert_videos = insert_videos[:-2] + ";\n"
insert_has_tag = insert_has_tag[:-2] + ";\n"

csv_file.close()

################################################################################################

create_tables = """
CREATE TABLE Channels (
    channelId           VARCHAR(32) PRIMARY KEY,
    channelName         VARCHAR(255)
);

CREATE TABLE Videos (
    videoId             VARCHAR(32) PRIMARY KEY,
    title               VARCHAR(255),
    publishedAt         DATETIME,
    channelId           VARCHAR(32),
    categoryId          INT,
    trendingDate        DATETIME,
    viewCount           INT,
    likes               INT,
    dislikes            INT,
    commentCount        INT,
    commentsDisabled    BIT,
    ratingsDisabled     BIT,
    description         TEXT,
    FOREIGN KEY (channelId) REFERENCES Channels(channelId)
);

CREATE TABLE VideoTags (
    tagId               INT PRIMARY KEY,
    tagName             VARCHAR(255)
);

CREATE TABLE HasTag (
    videoId             VARCHAR(32),
    tagId               INT,
    PRIMARY KEY (videoId, tagId),
    FOREIGN KEY (videoId) REFERENCES Videos(videoId)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (tagId) REFERENCES VideoTags(tagId)
        ON DELETE CASCADE ON UPDATE CASCADE
);
"""

with codecs.open("output/build.sql", 'wb', 'utf-8') as sql_file:
    sql_file.write(create_tables + '\n\n')
    sql_file.write(insert_channels + '\n\n')
    sql_file.write(insert_video_tags + '\n\n')
    sql_file.write(insert_videos + '\n\n')
    sql_file.write(insert_has_tag + '\n\n')
